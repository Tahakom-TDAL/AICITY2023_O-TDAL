pytorchvideo.models.resnet 
=================================

Building blocks for Resnet and resnet-like models

.. automodule:: pytorchvideo.models.resnet
  :members: