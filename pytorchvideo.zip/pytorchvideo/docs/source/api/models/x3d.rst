pytorchvideo.models.x3d 
=================================


.. automodule:: pytorchvideo.models.x3d
  :members: