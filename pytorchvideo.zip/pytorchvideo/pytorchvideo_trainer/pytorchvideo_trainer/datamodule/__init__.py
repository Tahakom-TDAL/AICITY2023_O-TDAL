# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.

from .datamodule import PyTorchVideoDataModule  # noqa


__all__ = [
    "PyTorchVideoDataModule",
]
