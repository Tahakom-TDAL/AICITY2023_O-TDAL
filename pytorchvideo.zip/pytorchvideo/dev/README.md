## Running Linter


Before running the linter, please ensure that you installed the necessary additional linter dependencies.
If not installed, check the [install-README](https://github.com/facebookresearch/pytorchvideo/blob/main/INSTALL.md) on how to do it.

Post that, you can run the linter from the project root using,

```
./dev/linter.sh
```
