# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.

from .ego4d_dataset import Ego4dMomentsDataset
