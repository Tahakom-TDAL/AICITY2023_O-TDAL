detectron2.evaluation 
=============================

.. automodule:: detectron2.evaluation
    :members:
    :undoc-members:
    :show-inheritance:
